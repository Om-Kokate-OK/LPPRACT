import java.util.HashMap;

/**
 * Defines all instruction tables used in Pass-I of a Two-Pass Assembler.
 * 
 * AD = Assembler Directives (e.g., START, END, ORIGIN, EQU, LTORG)
 * IS = Imperative Statements (e.g., MOVER, ADD, SUB)
 * DL = Declarative Statements (e.g., DC, DS)
 * RG = Registers (e.g., AREG, BREG)
 * CC = Condition Codes (e.g., LT, EQ, GT)
 */
public class INSTtable {

    // HashMaps for each instruction category
    HashMap<String, Integer> AD, RG, IS, CC, DL;

    public INSTtable() {
        // Initialize HashMaps
        AD = new HashMap<>();
        CC = new HashMap<>();
        IS = new HashMap<>();
        RG = new HashMap<>();
        DL = new HashMap<>();

        // Declarative statements
        DL.put("DC", 1);
        DL.put("DS", 2);

        // Imperative statements (Machine operations)
        IS.put("STOP", 0);
        IS.put("ADD", 1);
        IS.put("SUB", 2);
        IS.put("MULT", 3);
        IS.put("MOVER", 4);
        IS.put("MOVEM", 5);
        IS.put("COMP", 6);
        IS.put("BC", 7);
        IS.put("DIV", 8);
        IS.put("READ", 9);
        IS.put("PRINT", 10);

        // Condition codes for branching
        CC.put("LT", 1);
        CC.put("LE", 2);
        CC.put("EQ", 3);
        CC.put("GT", 4);
        CC.put("GE", 5);
        CC.put("ANY", 6);

        // Assembler Directives (handled by assembler itself)
        AD.put("START", 1);
        AD.put("END", 2);
        AD.put("ORIGIN", 3);
        AD.put("EQU", 4);
        AD.put("LTORG", 5);

        // Register codes
        RG.put("AREG", 1);
        RG.put("BREG", 2);
        RG.put("CREG", 3);
        RG.put("DREG", 4);
    }

    /**
     * Returns which type (AD, IS, DL, RG, CC) the given mnemonic belongs to.
     */
    public String getType(String s) {
        s = s.toUpperCase();
        if (AD.containsKey(s)) return "AD";
        else if (IS.containsKey(s)) return "IS";
        else if (CC.containsKey(s)) return "CC";
        else if (DL.containsKey(s)) return "DL";
        else if (RG.containsKey(s)) return "RG";
        return "";
    }

    /**
     * Returns the operation code (integer) of a mnemonic.
     */
    public int getCode(String s) {
        s = s.toUpperCase();
        if (AD.containsKey(s)) return AD.get(s);
        else if (IS.containsKey(s)) return IS.get(s);
        else if (CC.containsKey(s)) return CC.get(s);
        else if (DL.containsKey(s)) return DL.get(s);
        else if (RG.containsKey(s)) return RG.get(s);
        return -1;
    }
}
