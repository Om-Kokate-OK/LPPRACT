import java.io.*;
import java.util.*;

/**
 * Pass-I of a Two-Pass Assembler for a pseudo-machine.
 * 
 * Generates:
 *   1. Intermediate Code (IC.txt)
 *   2. Symbol Table (SYMTAB.txt)
 *   3. Literal Table (LITTAB.txt)
 *   4. Pool Table (POOLTAB.txt)
 */
public class PassOne {
    int lc = 0;                          // Location Counter
    int littab_ptr = 0, pooltab_ptr = 0; // Literal table and pool table pointers
    int symIndex = 0, litIndex = 0;      // Symbol and Literal indices
    LinkedHashMap<String, TableRow> SYMTAB; // Symbol Table
    ArrayList<TableRow> LITTAB;             // Literal Table
    ArrayList<Integer> POOLTAB;             // Pool Table
    private BufferedReader br;

    public PassOne() {
        SYMTAB = new LinkedHashMap<>();
        LITTAB = new ArrayList<>();
        POOLTAB = new ArrayList<>();
        POOLTAB.add(0); // Pool always starts with index 0
    }

    public static void main(String[] args) {
        PassOne one = new PassOne();
        try {
            one.parseFile();
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }

    /**
     * Reads input assembly file line-by-line and performs Pass-I.
     */
    public void parseFile() throws Exception {
        String line, code;
        br = new BufferedReader(new FileReader("input1.asm"));
        BufferedWriter bw = new BufferedWriter(new FileWriter("IC.txt"));
        INSTtable lookup = new INSTtable();

        while ((line = br.readLine()) != null) {
            if (line.trim().isEmpty()) continue; // Skip empty lines

            String parts[] = line.trim().split("\\s+");
            code = "";

            // Handle single-word instructions like STOP, END, LTORG safely
            if (parts.length == 1) {
                String token = parts[0].toUpperCase();

                // STOP (no operands)
                if (token.equals("STOP")) {
                    code = "(IS,00)";
                    bw.write(code + "\n");
                    lc++;
                    continue;
                }

                // LTORG (assign literals from literal table)
                else if (token.equals("LTORG")) {
                    int ptr = POOLTAB.get(pooltab_ptr);
                    for (int j = ptr; j < littab_ptr; j++) {
                        lc++;
                        LITTAB.set(j, new TableRow(LITTAB.get(j).getSymbol(), lc));
                        code = "(DL,01)\t(C," + LITTAB.get(j).getSymbol() + ")";
                        bw.write(code + "\n");
                    }
                    pooltab_ptr++;
                    POOLTAB.add(littab_ptr);
                    continue;
                }

                // END (final literal assignment)
                else if (token.equals("END")) {
                    int ptr = POOLTAB.get(pooltab_ptr);
                    for (int j = ptr; j < littab_ptr; j++) {
                        lc++;
                        LITTAB.set(j, new TableRow(LITTAB.get(j).getSymbol(), lc));
                        code = "(DL,01)\t(C," + LITTAB.get(j).getSymbol() + ")";
                        bw.write(code + "\n");
                    }
                    pooltab_ptr++;
                    POOLTAB.add(littab_ptr);
                    code = "(AD,02)";
                    bw.write(code + "\n");
                    break;
                }
            }

            // Skip invalid short lines
            if (parts.length < 2) continue;

            // Handle Label (first column)
            if (!parts[0].isEmpty() && !lookup.getType(parts[0]).equals("IS") && !lookup.getType(parts[0]).equals("AD")) {
                if (SYMTAB.containsKey(parts[0]))
                    SYMTAB.put(parts[0], new TableRow(parts[0], lc, SYMTAB.get(parts[0]).getIndex()));
                else
                    SYMTAB.put(parts[0], new TableRow(parts[0], lc, ++symIndex));
            }

            // START directive
            if (parts[1].equalsIgnoreCase("START")) {
                lc = expr(parts[parts.length - 1]);
                code = "(AD,01)\t(C," + lc + ")";
                bw.write(code + "\n");
                continue;
            }

            // ORIGIN directive
            if (parts[1].equalsIgnoreCase("ORIGIN")) {
                if (parts.length > 2) {
                    lc = expr(parts[2]);
                    code = "(AD,03)\t(C," + lc + ")";
                    bw.write(code + "\n");
                }
                continue;
            }

            // EQU directive
            if (parts[1].equalsIgnoreCase("EQU")) {
                int loc = expr(parts[2]);
                if (SYMTAB.containsKey(parts[0]))
                    SYMTAB.put(parts[0], new TableRow(parts[0], loc, SYMTAB.get(parts[0]).getIndex()));
                else
                    SYMTAB.put(parts[0], new TableRow(parts[0], loc, ++symIndex));
                code = "(AD,04)\t(C," + loc + ")";
                bw.write(code + "\n");
                continue;
            }

            // DS directive (Define Storage)
            if (parts[1].equalsIgnoreCase("DS")) {
                int size = Integer.parseInt(parts[2].replace("'", ""));
                code = "(DL,02)\t(C," + size + ")";
                bw.write(code + "\n");
                lc += size;
                continue;
            }

            // DC directive (Define Constant)
            if (parts[1].equalsIgnoreCase("DC")) {
                int constant = Integer.parseInt(parts[2].replace("'", ""));
                lc++;
                code = "(DL,01)\t(C," + constant + ")";
                bw.write(code + "\n");
                continue;
            }

            // Handle Imperative Statements (e.g., MOVER, ADD, MOVEM)
            if (lookup.getType(parts[1]).equals("IS")) {
                code = "(IS,0" + lookup.getCode(parts[1]) + ")\t";
                int j = 2;
                String code2 = "";

                while (j < parts.length) {
                    parts[j] = parts[j].replace(",", "");

                    // Register operand
                    if (lookup.getType(parts[j]).equals("RG")) {
                        code2 += lookup.getCode(parts[j]) + "\t";
                    }

                    // Literal operand
                    else if (parts[j].contains("=")) {
                        parts[j] = parts[j].replace("=", "").replace("'", "");
                        LITTAB.add(new TableRow(parts[j], -1, ++litIndex));
                        littab_ptr++;
                        code2 += "(L," + litIndex + ")";
                    }

                    // Symbol operand
                    else {
                        if (!SYMTAB.containsKey(parts[j]))
                            SYMTAB.put(parts[j], new TableRow(parts[j], -1, ++symIndex));
                        int ind = SYMTAB.get(parts[j]).getIndex();
                        code2 += "(S," + ind + ")";
                    }
                    j++;
                }

                lc++; // Increase LC after each instruction
                code = code + code2;
                bw.write(code + "\n");
            }
        }

        bw.close();
        printSYMTAB();
        printLITTAB();
        printPOOLTAB();
    }

    /**
     * Expression evaluation (for ORIGIN/EQU like A+1 or L2-3)
     */
    public int expr(String str) {
        int temp = 0;
        if (str.contains("+")) {
            String splits[] = str.split("\\+");
            temp = SYMTAB.get(splits[0]).getAddress() + Integer.parseInt(splits[1]);
        } else if (str.contains("-")) {
            String splits[] = str.split("\\-");
            temp = SYMTAB.get(splits[0]).getAddress() - Integer.parseInt(splits[1]);
        } else {
            temp = Integer.parseInt(str);
        }
        return temp;
    }

    // Prints Symbol Table
    void printSYMTAB() throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter("SYMTAB.txt"));
        System.out.println("\nSYMBOL TABLE");
        for (String key : SYMTAB.keySet()) {
            TableRow value = SYMTAB.get(key);
            System.out.println(value.getIndex() + "\t" + value.getSymbol() + "\t" + value.getAddress());
            bw.write(value.getIndex() + "\t" + value.getSymbol() + "\t" + value.getAddress() + "\n");
        }
        bw.close();
    }

    // Prints Literal Table
    void printLITTAB() throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter("LITTAB.txt"));
        System.out.println("\nLITERAL TABLE");
        for (int i = 0; i < LITTAB.size(); i++) {
            TableRow row = LITTAB.get(i);
            System.out.println((i + 1) + "\t" + row.getSymbol() + "\t" + row.getAddress());
            bw.write((i + 1) + "\t" + row.getSymbol() + "\t" + row.getAddress() + "\n");
        }
        bw.close();
    }

    // Prints Pool Table
    void printPOOLTAB() throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter("POOLTAB.txt"));
        System.out.println("\nPOOLTAB");
        System.out.println("Index\t#first");
        for (int i = 0; i < POOLTAB.size(); i++) {
            System.out.println((i + 1) + "\t" + POOLTAB.get(i));
            bw.write((i + 1) + "\t" + POOLTAB.get(i) + "\n");
        }
        bw.close();
    }
}
