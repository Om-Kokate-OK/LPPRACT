/**
 * Represents one row of Symbol Table or Literal Table.
 * 
 * Each TableRow stores:
 *   symbol → name of label/literal
 *   address → assigned address value
 *   index → its serial number (for reference in IC)
 */
public class TableRow {
    String symbol; // Symbol name (e.g., A, B, L1, =’14’)
    int address;   // Memory address of symbol or literal
    int index;     // Entry number in SYMTAB or LITTAB

    // Constructor for symbol/literal without index
    public TableRow(String symbol, int address) {
        this.symbol = symbol;
        this.address = address;
        this.index = 0;
    }

    // Constructor for symbol/literal with index
    public TableRow(String symbol, int address, int index) {
        this.symbol = symbol;
        this.address = address;
        this.index = index;
    }

    // Getter & Setter methods
    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }

    public int getAddress() { return address; }
    public void setAddress(int address) { this.address = address; }

    public int getIndex() { return index; }
    public void setIndex(int index) { this.index = index; }
}
