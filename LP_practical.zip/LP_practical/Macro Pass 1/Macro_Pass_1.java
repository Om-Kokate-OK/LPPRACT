import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;

/**
 * ---------------------------------------------
 *  MACRO PASS 1
 * ---------------------------------------------
 * 
 * This program performs the first pass of the macro processor.
 * It identifies and processes macros from the input assembly file
 * ("macro_input.asm") and generates the following output files:
 * 
 *  1️⃣ MNT  - Macro Name Table
 *  2️⃣ MDT  - Macro Definition Table
 *  3️⃣ KPDT - Keyword Parameter Default Table
 *  4️⃣ PNT  - Parameter Name Table
 *  5️⃣ IR   - Intermediate Code (non-macro instructions)
 * 
 * ---------------------------------------------
 *  WORKFLOW SUMMARY
 * ---------------------------------------------
 * 
 *  Input: macro_input.asm
 *  Output: 
 *   - mnt.txt      → Macro name, PP, KP, MDTP, KPDTP
 *   - mdt.txt      → Macro definitions with parameter references
 *   - kpdt.txt     → Keyword parameters and default values
 *   - pntab.txt    → Parameter name mapping
 *   - intermediate.txt → Source code excluding macro definitions
 * ---------------------------------------------
 */
public class Macro_Pass_1 {

    public static void main(String[] args) throws IOException {

        // Reading input assembly file containing macro definitions
        BufferedReader br = new BufferedReader(new FileReader("macro_input.asm"));

        // Creating output files
        FileWriter mnt = new FileWriter("mnt.txt");          // Macro Name Table
        FileWriter mdt = new FileWriter("mdt.txt");          // Macro Definition Table
        FileWriter kpdt = new FileWriter("kpdt.txt");        // Keyword Parameter Default Table
        FileWriter pnt = new FileWriter("pntab.txt");        // Parameter Name Table
        FileWriter ir = new FileWriter("intermediate.txt");  // Intermediate (non-macro) file

        // Parameter Name Table stored temporarily in memory
        LinkedHashMap<String, Integer> pntab = new LinkedHashMap<>();

        // Variables
        String line;
        String macroName = null;  // To store current macro name
        int mdtp = 1;             // MDT Pointer
        int kpdtp = 0;            // KPDT Pointer
        int paramNo = 1;          // Parameter number in PNTAB
        int pp = 0, kp = 0;       // Positional and Keyword Parameter count
        int flag = 0;             // Indicates whether inside MACRO definition

        // ------------------------------
        // MAIN LINE-BY-LINE PROCESSING
        // ------------------------------
        while ((line = br.readLine()) != null) {

            String parts[] = line.trim().split("\\s+");

            // ------------------------------
            // 1️⃣ Start of MACRO definition
            // ------------------------------
            if (parts[0].equalsIgnoreCase("MACRO")) {
                flag = 1; // Macro definition has started

                // Read the next line (macro header)
                line = br.readLine();
                parts = line.trim().split("\\s+");
                macroName = parts[0];

                // If no parameters are given
                if (parts.length <= 1) {
                    mnt.write(parts[0] + "\t" + pp + "\t" + kp + "\t" + mdtp + "\t" + (kp == 0 ? kpdtp : (kpdtp + 1)) + "\n");
                    continue;
                }

                // ------------------------------
                // 2️⃣ Process each parameter
                // ------------------------------
                for (int i = 1; i < parts.length; i++) {
                    parts[i] = parts[i].replaceAll("[&,]", ""); // Remove '&' and ','

                    // Keyword parameter (contains '=')
                    if (parts[i].contains("=")) {
                        ++kp;
                        String keywordParam[] = parts[i].split("=");

                        // Add parameter to PNTAB
                        pntab.put(keywordParam[0], paramNo++);

                        // Add entry to KPDTAB
                        if (keywordParam.length == 2) {
                            kpdt.write(keywordParam[0] + "\t" + keywordParam[1] + "\n");
                        } else {
                            kpdt.write(keywordParam[0] + "\t-\n"); // Default value not provided
                        }
                    } 
                    // Positional parameter
                    else {
                        pntab.put(parts[i], paramNo++);
                        pp++;
                    }
                }

                // Add entry to MNT (Macro Name Table)
                mnt.write(parts[0] + "\t" + pp + "\t" + kp + "\t" + mdtp + "\t" + (kp == 0 ? kpdtp : (kpdtp + 1)) + "\n");

                // Update KPDT pointer
                kpdtp = kpdtp + kp;

            }

            // ------------------------------
            // 3️⃣ End of MACRO definition (MEND)
            // ------------------------------
            else if (parts[0].equalsIgnoreCase("MEND")) {
                mdt.write(line + "\n"); // Write MEND into MDT
                flag = kp = pp = 0;     // Reset counters
                mdtp++;
                paramNo = 1;

                // Write parameter names in PNTAB file
                pnt.write(macroName + ":\t");
                Iterator<String> itr = pntab.keySet().iterator();
                while (itr.hasNext()) {
                    pnt.write(itr.next() + "\t");
                }
                pnt.write("\n");

                pntab.clear(); // Clear for next macro
            }

            // ------------------------------
            // 4️⃣ Inside MACRO definition body
            // ------------------------------
            else if (flag == 1) {
                for (int i = 0; i < parts.length; i++) {
                    if (parts[i].contains("&")) {
                        // Replace parameter name with its index from PNTAB
                        parts[i] = parts[i].replaceAll("[&,]", "");
                        mdt.write("(P," + pntab.get(parts[i]) + ")\t");
                    } else {
                        // Normal instruction or label
                        mdt.write(parts[i] + "\t");
                    }
                }
                mdt.write("\n");
                mdtp++;
            }

            // ------------------------------
            // 5️⃣ Non-macro statements → Intermediate file
            // ------------------------------
            else {
                ir.write(line + "\n");
            }
        }

        // ------------------------------
        // Close all files
        // ------------------------------
        br.close();
        mdt.close();
        mnt.close();
        ir.close();
        pnt.close();
        kpdt.close();

        System.out.println("✅ Macro Pass 1 Processing Done Successfully!");
    }
}
